# WINNER'S LOUNGE — CC BUILD SPEC
### Fox Pit floor 6 (rooftop). Build to this spec. Package date 2026-07-24.

> Read `01_SESSION_OPERATING_RULES` and the project MASTER STATE LEDGER first.
> This spec adds to them; where this spec and an older handoff disagree, the ledger wins.
> **Nothing here is "done" until a device screenshot proves it.** Code that compiles is
> "coded, unverified."

---

## 0. WHAT THIS FLOOR IS

The Winner's Lounge is the reward for beating Boss Fox. It is **hidden** until that
happens, sits at elevator **STOP_1 (map y 1208)**, and is a **PvP mode — player versus
player, never versus the house.** The winner takes Boss Fox's throne and becomes the new
boss, then challenges other players and bosses from other towers.

**It is DEALER-LESS.** The Locksmith never appears on this floor. Do not import, reference,
or composite any `locksmith_*` asset here. The dealing is code.

---

## 1. COORDINATES — VERIFY AT SESSION START, DON'T ASSUME

| Thing | Value |
|---|---|
| Elevator stop | STOP_1, map y **1208** of 4500 (top edge of Frank's marker band = stop line) |
| Map | `tower_map_clean.png` 1620x4500 — **IMMUTABLE**, never painted on |
| Test target | dev package on the Z-Flip 6, never the release/baked app |
| Unlock gate | Boss Fox defeated. Locked = dim + tier-key icon on the floor-select panel |

**Report before editing:** `git branch --show-current`, `git log --oneline -6`, and the
`file:line` of (a) the floor-select panel, (b) the elevator arrival handler, (c) wherever
a room scene is currently composited. Recon is read-only.

---

## 2. ASSET MANIFEST — WHAT SHIPPED IN THIS ZIP

### 2.1 `assets/winners_lounge/` — arrival cinematic plates (627x627 each, RGB)
| file | role |
|---|---|
| `wl_plate_wide_establishing.png` | beat 1 — opens on the room |
| `wl_plate_throne_left_3q.png` | beat 2 |
| `wl_plate_throne_right_3q.png` | beat 3 |
| `wl_plate_throne_straight.png` | beat 4 — closes on the throne |

### 2.2 `assets/lounge_rig/` — the table rig (all RGBA, true alpha)
| file | size | role |
|---|---|---|
| `lounge_table_seated.png` | 750x509 | octagon electronic table, 3/4 player angle |
| `lounge_table_topdown.png` | 617x601 | same table, true overhead |
| `lounge_screen_player_hand.png` | 570x363 | **the landscape screen CC cuts to when a player sits** |
| `lounge_screen_boss_facing.png` | 575x364 | back of that screen, across the table |
| `lounge_screen_left_3q.png` | 531x395 | left 3/4 angle |
| `lounge_screen_phone_portrait.png` | 272x512 | the portrait CHOOSING screen |
| `lounge_deal_blueprint.svg` | — | the top-down deal diagram; design SoT for §6 |

### 2.3 `assets/cutouts/`
| file | size | role |
|---|---|---|
| `bossfox_welcome_lounge.png` | 751x1299 | Boss Fox ushering the player in — final cinematic beat |

### 2.4 `assets/avatar_rig/` — 18 pieces + `_INDEX.txt` + `_rig_index.json`
Male and female: torso, upper arm, forearm, thigh, shin — each in near and far.
**No heads.** Head slot is a GOLD COIN placeholder that CC draws from tokens.
`brass_caps` in the index are pivot **candidates**, not confirmed pivots — bind with the
cal tool (§9).

### 2.5 `assets/unidentified/` — READ §10 BEFORE TOUCHING
Six files from `Pit_Tower_Boss_level.zip`. **Do not wire these to anything yet.**

### 2.6 NOT IN THIS ZIP — STILL OWED
- **Top-down monitor cutouts.** Prompt written, art not generated. Build the slot per
  §5.4 and render a **stub that uses the new system** — never fall back to hiding the layer.

---

## 3. ARRIVAL — THE CINEMATIC

Fires when the player exits the elevator car at STOP_1.

1. Order: **wide establishing → throne left 3/4 → throne right 3/4 → throne straight on.**
   Opens on the room, closes on the throne.
2. ~2.5s per plate, ~10s total. Slow push-in per plate, scale 1.0 → ~1.08, cross-fade
   between plates. Ease in/out. **No hard cuts.**
3. **Final beat:** `bossfox_welcome_lounge.png` composited over the last plate, arm
   extended, ushering the player in. It is a **cutout** — never bake it into a plate.
4. **Plays in full on the first visit only.** Skipped automatically on every later visit.
5. **Skippable at any point by tap.** A quiet affordance, not a shouting button.
6. Persist `hasSeenLoungeArrival` per user. Server-side, same store as the rest of the
   user record — not client-only.

---

## 4. THE TABLE RIG — LAYERED, NOT BAKED

There is **exactly ONE table** on this floor and it is a **cutout**. Octagon, electronic,
black glass top, orange bezel. **Not green felt. No dealer, no dealer seat.**

Assemble piece by piece in **swappable layers**, back to front:

```
z0   room backdrop            wl_plate_* (the arrival cinematic's last frame holds)
z1   chair                    FIXED position, FIXED size — never changes, never swaps
z2   player cutout            THE ONLY SWAPPABLE LAYER  (§5)
z3   table + front screen     lounge_table_seated.png + lounge_screen_player_hand.png
z4   top-down screen(s)       §5.4 — stub until art lands
z5   live overlays            cards, coins, reveals — CC-drawn, never baked
```

The player cutout is **sandwiched**: behind the front screen, in front of the chair. The
screen occludes the lower body naturally. This is what makes any body size fit one slot.

**Do not bake any two of these layers into a single image.** If you find yourself
compositing to a flat PNG to "simplify," stop — that breaks the swap.

---

## 5. SLOTS — THE PART THAT MUST NOT BE GUESSED

### 5.1 The rule
Slot positions come from **the architect's own marks or from CC on-device**. Never from
blind measurement, never from Claude's arithmetic, never derived from art. This project
has lost days to derived coordinates (retired for good: plaque-mapY, floor-seams,
avatar-feet clustering, ledge-deck measurement, sheet-origin-as-map-origin).

### 5.2 Build the calibration path FIRST
Extend the existing cal tool (the gear "cal" button) with a **lounge slot mode**:

- Render the rig at z0–z3 with the chair, table, and screens draggable.
- Draggable handles for: `CHAIR_SLOT`, `PLAYER_SLOT`, `TABLE_ANCHOR`, `FRONT_SCREEN_ANCHOR`,
  `TOPDOWN_SCREEN_ANCHOR` (one per screen; support N).
- Emit JSON on save. Frank pastes it back. CC bakes it into `LOUNGE_SLOTS`.
- **Until that JSON exists, every anchor reads from a single named constants block with a
  `// UNCALIBRATED` marker.** Do not scatter magic numbers through the render code.

### 5.3 Player slot contract
- **One slot, one position, one scale**, regardless of the character's body size.
- The cutout drops in at that fixed transform. Do not auto-fit, do not scale to bounds,
  do not centre on the sprite's bbox — those all move the head when the body changes.
- Registration is the **seat contact point**, not the sprite centre.
- Male and female cutouts use the **same** slot. If one sits wrong, the art is wrong, not
  the slot — report it, don't add a per-sex offset.

### 5.4 Top-down screens
- Tilted back so the face reads from the overhead camera, with a sliver of the top edge
  showing. Blank dark glass — CC overlays content live.
- **Room for more than one.** Make the anchor list an array from day one; do not hardcode
  a single screen.
- Art not delivered. Stub = a rounded dark-glass rectangle drawn from tokens with the
  orange bezel line, at the calibrated anchor. **The stub uses the new system.** No
  fallback path, no hidden layer, no `if (!asset) return`.

---

## 6. THE DEAL — TOP-DOWN BLUEPRINT

Design SoT: `assets/lounge_rig/lounge_deal_blueprint.svg`.

- **Deck / deal origin on the LEFT.** The deal animation starts there — **never** from the
  opponent's side.
- **Alternating deal, 5 each, face-down**, numbered 1→10: YOU s1, OPP s1, YOU s2, OPP s2 …
  left to right.
- **[PINNED] The ten cards go in the CENTRE.**
- **[PINNED] POT:** at stake selection a coin amount from **each side** moves to the
  **middle** to form the pot, then the pile **pushes RIGHT** as a digital stack. Digital
  coins — reuse the existing card/coin designs.
- Press a card → flip (category + question) → choose on phone → LOCK → back to top-down →
  reveal ✓/✗ per question → pot and bank update.

---

## 7. THE FLOW — PHONE ↔ SCREEN

```
1. Press START             → table appears / slides out
2. Cards dealt digitally to the table
3. PHONE (portrait)        → the CHOOSING surface. Tiles stacked in a COLUMN. Keep / toss.
4. LANDSCAPE FLAT SCREEN   → flips back to display what was locked in / discarded
5. Back and forth: phone (choose) ↔ landscape screen (display + reveal)
   The TOP-DOWN screen mirrors coins/cards/reveals so the player sees it from above.
```

`lounge_screen_phone_portrait.png` is the choosing surface. `lounge_screen_player_hand.png`
is the wide landscape screen — it must lay out and reveal **all five slates side by side**.
That is the one CC cuts to when a player sits down.

---

## 8. GAMEPLAY — PROPOSED, ARCHITECT TO CONFIRM

Marked **[PROPOSED]** because the PvP mechanics spec is orchestrator-owed and not yet
signed off. Build the round loop; leave the numbers as config.

**[PROPOSED] Round loop (head-to-head, no dealer):**
1. Both players seated → each picks **1–5 categories**. Breadth unlocks stake tiers.
2. Stake selection → pot forms per §6.
3. Deal 5 each, alternating, face-down, ten in the centre.
4. Keep / toss on the phone. **Boss Fox tier minimum applies: no fewer than 5 played.**
5. Both lock → reveal ✓/✗ per question on the landscape + top-down screens.
6. Pot settles. Bank updates. Loser's throne claim fails.

**[PROPOSED] Throne succession:** the winner of the Lounge takes the throne and becomes
the tower's boss, challengeable by other players. New boss leaderboard + tournament —
**not in this build.** Scaffold the `isTowerBoss` field only.

**[PINNED, NOT THIS BUILD] Shadow slates:** Lounge winners play real FUTURE-event slates in
a no-money shadow mode, then are told what they would have won or lost. Do not build now.

**No tipping the Locksmith on this floor** — she isn't here. If a lockpick trigger is
wanted in the Lounge it needs a different mechanic; do not port the tip flow.

---

## 9. AVATAR RIG ON THIS FLOOR

The seated player uses the **same 18-piece rig** as the stair climb, in a seated pose:

- Z-order back to front: far thigh → far shin → far upper arm → far forearm → torso →
  coin head → near thigh → near shin → near upper arm → near forearm.
- Head = **gold coin placeholder** drawn from tokens (circle, brass fill, lighter inner
  disc, thin darker rim). No head art exists and none is coming until the user avatar badge
  renders. Do not source a head from any other asset.
- Pivots come from the cal tool. `brass_caps` are candidates only.

---

## 10. UNIDENTIFIED ASSETS — DO NOT WIRE

`assets/unidentified/` holds six files split out of `Pit_Tower_Boss_level.zip`:

| file | size | measured |
|---|---|---|
| `plate37_scene.png` | 1037x1115 | one scene, 85% dark pixels, warm palette |
| `plate38_piece_1.png` | 569x668 | cutout |
| `plate38_piece_2.png` | 475x462 | cutout |
| `plate38_piece_3.png` | 211x299 | cutout |
| `plate38_piece_4.png` | 300x288 | cutout, 489 pinholes filled |
| `plate38_piece_5.png` | 157x100 | cutout |

They were split mechanically by connected component, despilled, and hole-healed. **Their
subject was not visually confirmed and they carry no real names.** Per the standing rule —
never name a file for CC without confirming what it is — these stay parked until the
architect names them. Do not guess, do not wire, do not rename.

---

## 11. GATES — EVERY ONE MUST PASS

1. `.bak` before every edit; report path and size.
2. **Replace, don't layer.** New code removes the old path. Grep after editing; any
   surviving old-path reference is a leak — remove it.
3. **No silent catch.** `console.error` on every catch. Errors visible on screen.
4. Sprite integrity on import: zero interior holes, zero pixels where `G > R+25 && G > B+25`,
   across every file in `avatar_rig/`, `cutouts/`, `lounge_rig/`, `winners_lounge/`. If a file
   fails, report the filename and count and **STOP** — the fix belongs upstream in the slice.
   Never patch at draw time, never back a sprite with an opaque rectangle to hide holes.
5. Tokens by name, never raw hex.
6. Bump `versionCode` every build. Verify it in the build output.
7. **No push without explicit approval.**
8. Device screenshot is the only proof of done — arrival cinematic, seated player in the
   slot with the coin head, and the deal reaching reveal. Three shots, not one.

---

## 12. NEXT SESSION — DO THIS FIRST

1. Read this spec and the ledger. Do not re-derive; do not re-propose retired ideas.
2. Confirm branch + HEAD; reconcile against the ledger's §2/§3.
3. Active thread: build the **cal tool lounge slot mode (§5.2)** before any anchor is
   written. Everything downstream is blocked on real coordinates.
4. Update the ledger at session end — append commits, resolve contradictions, promote new
   never-re-litigate facts. Never replace it with a thin summary.

END SPEC.
